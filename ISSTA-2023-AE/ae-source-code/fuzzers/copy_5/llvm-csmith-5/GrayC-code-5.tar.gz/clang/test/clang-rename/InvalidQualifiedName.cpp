struct S {
};

// RUN: clang-rename -force -qualified-name S2 -new-name=T %s --
