#import <SomeFramework/public_header2.h>
#import "public_header3.h" // includer-relative
void from_framework(void);
