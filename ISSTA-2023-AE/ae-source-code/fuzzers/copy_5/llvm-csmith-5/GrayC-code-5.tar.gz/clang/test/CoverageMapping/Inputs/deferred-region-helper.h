void included_func() {
  if (false)
    return;
  return;
}
