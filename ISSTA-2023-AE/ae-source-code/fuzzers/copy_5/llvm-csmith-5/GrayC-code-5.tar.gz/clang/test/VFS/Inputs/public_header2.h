// public_header2.h
