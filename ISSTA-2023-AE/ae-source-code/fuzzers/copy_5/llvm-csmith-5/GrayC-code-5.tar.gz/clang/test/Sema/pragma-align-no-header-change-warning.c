// RUN: %clang_cc1 -triple i686-apple-darwin9 -fsyntax-only -Wpragma-pack -I %S/Inputs -verify %s
// expected-no-diagnostics

#include "pragma-align-no-header-change-warning.h"

