void bar(void);
