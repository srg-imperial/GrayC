// Error.h

#error Should not include this header in a module
