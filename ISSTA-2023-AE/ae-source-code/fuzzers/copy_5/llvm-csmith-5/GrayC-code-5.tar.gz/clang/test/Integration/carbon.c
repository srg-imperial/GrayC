// RUN: %clang -fsyntax-only %s
// REQUIRES: macos-sdk-10.12
#ifdef __APPLE__
#include <Carbon/Carbon.h>
#endif
