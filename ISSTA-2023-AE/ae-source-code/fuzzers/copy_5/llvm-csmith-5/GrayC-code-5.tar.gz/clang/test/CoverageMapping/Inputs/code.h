// Some code for the middle of a program

x = x;
if (x == 0) {
  x = 1;
} else {
  x = 2;
}
if (true) {
  x = x;
} else {
  x = x;
}
