// public_header3.h
