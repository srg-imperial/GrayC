// This comment is stripped, so size is changed when file is opened
#define FRAMEWORK 0
