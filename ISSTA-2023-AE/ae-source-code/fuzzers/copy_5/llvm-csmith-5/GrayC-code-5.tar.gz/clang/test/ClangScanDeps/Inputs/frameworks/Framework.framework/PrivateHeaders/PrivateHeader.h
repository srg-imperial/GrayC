// This comment is stripped when file is opened, so size will change
#define PRIV 0
