struct Foo {};
