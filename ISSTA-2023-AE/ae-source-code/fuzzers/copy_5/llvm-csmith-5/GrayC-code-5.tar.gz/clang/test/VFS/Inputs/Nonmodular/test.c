// expected-no-diagnostics

#include "umbrella.h"
